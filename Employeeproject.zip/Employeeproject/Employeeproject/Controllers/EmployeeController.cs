﻿using Employeeproject.Model;
using Employeeproject.Service;
using Microsoft.AspNetCore.Mvc;

namespace Employeeproject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeController : Controller
    {

        private readonly EmployeeService _service;

        public EmployeeController(EmployeeService service)
        {
            _service = service;
        }


        [HttpGet]
        public IActionResult GetAll()
        {
            try
            {
                var employee = _service.GetAll();
                return Ok(employee);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error :{ex.Message} ");
            }
        }


        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            

            try
            {
                var emp = _service.GetById(id);
                return emp == null ? NotFound() : Ok(emp);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }


        [HttpPost]
        public IActionResult Create(Employee emp)
        {
            if (string.IsNullOrWhiteSpace(emp.FullName))
            {
                return BadRequest("Full Name is required.");
            }
            if (string.IsNullOrWhiteSpace(emp.Department))
            {
                return BadRequest("Department is required.");
            }
            if (emp.Salary < 0)
            {
                return BadRequest("Salary must be positive.");
            }

            var created = _service.Add(emp);
            return CreatedAtAction(nameof(GetById), new { id = created.EmployeeId }, created);
        }


        [HttpPut("{id}")]
        public IActionResult Update(int id, Employee emp)
        {
            if (string.IsNullOrWhiteSpace(emp.FullName))
            {
                return BadRequest("Full Name is required.");
            }
            if (string.IsNullOrWhiteSpace(emp.Department))
            {
                return BadRequest("Department is required.");
            }
            if (emp.Salary < 0)
            {
                return BadRequest("Salary must be positive.");
            }

            bool updated = _service.Update(id, emp);
            if (!updated) return NotFound();
            return NoContent();
        }


        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            bool deleted = _service.Delete(id);
            if (!deleted) return NotFound();
            return NoContent();
        }
    }
}
