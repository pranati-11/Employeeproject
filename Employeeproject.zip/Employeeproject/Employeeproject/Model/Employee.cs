﻿using System.ComponentModel.DataAnnotations;

namespace Employeeproject.Model
{
    public class Employee
    {
        public int EmployeeId { get; set; }

        [Required(ErrorMessage = "Full Name is required.")]
        [StringLength(50)]
        public string FullName { get; set; } 

        [Required(ErrorMessage = "Department is needed !")]

        [StringLength(50)]
        public string Department { get; set; } 
       

        [Range(0,double.MaxValue, ErrorMessage = "Salary must be greater than 0 .")]
        public decimal Salary { get; set; }

    }
}
