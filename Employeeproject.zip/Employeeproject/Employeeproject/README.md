﻿# Employee CRUD API (.NET Core)

## How to Run
1. Open solution in Visual Studio.
2. Press F5 or click Run.

## API Endpoints
- GET /api/employees → Get all
- GET /api/employees/{id} → Get by ID
- POST /api/employees → Add new
- PUT /api/employees/{id} → Update
- DELETE /api/employees/{id} → Delete

## Requirements Covered
✅ In-memory  
✅ REST methods  
✅ CRUD  
✅ Status codes  
✅ Input validations  
✅ Error handling